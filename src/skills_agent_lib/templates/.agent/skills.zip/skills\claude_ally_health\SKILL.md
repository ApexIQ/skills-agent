---
name: claude_ally_health
description: A health assistant skill for medical information analysis, symptom tracking,
  and wellness guidance.
source: https://github.com/huifer/Claude-Ally-Health
risk: safe
version: 0.1.0
---

# Claude Ally Health

## Overview

A health assistant skill for medical information analysis, symptom tracking, and wellness guidance.

## When to Use This Skill

Use this skill when you need to work with a health assistant skill for medical information analysis, symptom tracking, and wellness guidance..

## Instructions

This skill provides guidance and patterns for a health assistant skill for medical information analysis, symptom tracking, and wellness guidance..

For more information, see the [source repository](https://github.com/huifer/Claude-Ally-Health).
