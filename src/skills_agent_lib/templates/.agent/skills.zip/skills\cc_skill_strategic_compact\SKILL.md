---
name: cc_skill_strategic_compact
description: Development skill from everything-claude-code
author: affaan-m
version: '1.0'
---

# cc-skill-strategic-compact

Development skill skill.
