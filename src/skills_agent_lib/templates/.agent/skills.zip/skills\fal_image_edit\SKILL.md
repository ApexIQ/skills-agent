---
name: fal_image_edit
description: AI-powered image editing with style transfer and object removal
source: https://github.com/fal-ai-community/skills/blob/main/skills/claude.ai/fal-image-edit/SKILL.md
risk: safe
version: 0.1.0
---

# Fal Image Edit

## Overview

AI-powered image editing with style transfer and object removal

## When to Use This Skill

Use this skill when you need to work with ai-powered image editing with style transfer and object removal.

## Instructions

This skill provides guidance and patterns for ai-powered image editing with style transfer and object removal.

For more information, see the [source repository](https://github.com/fal-ai-community/skills/blob/main/skills/claude.ai/fal-image-edit/SKILL.md).
